package br.gov.sp.cps.imc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText nome;

    private EditText peso;

    private EditText altura;

    private Button btn_calcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        nome = findViewById(R.id.editTextNome);
        peso = findViewById(R.id.editTextPeso);
        altura = findViewById(R.id.editTextAltura);
        btn_calcular = findViewById(R.id.btnCalcular);
        btn_calcular.setOnClickListener(view -> {
            String valorNome = nome.getText().toString();
            double valorPeso = Double.parseDouble(peso.getText().toString());
            double valorAltura = Double.parseDouble(altura.getText().toString());

            double imc = valorPeso / Math.pow(valorAltura, 2.0);
            Intent intent;

            if (imc > 0 && imc < 18.5){
                intent = new Intent(this, MainActivity2.class);
                intent.putExtra("msg", "Abaixo do Peso, Procure um médico ou nutricionista");
            } else if (imc >= 18.5 && imc < 25.0){
                intent = new Intent(this, MainActivity3.class);
                intent.putExtra("msg", "Peso Normal nenhuma assistência profissional necessária");
            } else if (imc >= 25.0 && imc < 30.0){
                intent = new Intent(this, MainActivity4.class);
                intent.putExtra("msg", "Sobrepeso, considere ver assistência profissional");
            } else if (imc >= 30.0 && imc < 35.0){
                intent = new Intent(this, MainActivity5.class);
                intent.putExtra("msg", "Obesidade Grau I, Procure assistência médica ou nutricional");
            } else if (imc >= 35.0 && imc < 40.0){
                intent = new Intent(this, MainActivity6.class);
                intent.putExtra("msg", "Obesidade Grau II, Estado Severo procure um profissional imediatamente");
            } else if (imc >= 40.0){
                intent = new Intent(this, MainActivity7.class);
                intent.putExtra("msg", "Obesidade Grau III, Estado Crítico (risco de morte) procure um profissional imediatamente");
            } else {
                intent = new Intent(this, MainActivity8.class);
                startActivity(intent);
            }
            intent.putExtra("nome", valorNome);
            intent.putExtra("peso", String.format("%.2f", valorPeso));
            intent.putExtra("altura", String.format("%.2f", valorAltura));
            intent.putExtra("imc", String.format("%.2f", imc));
            startActivity(intent);
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}